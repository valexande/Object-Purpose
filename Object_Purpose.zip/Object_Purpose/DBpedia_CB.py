from SPARQLWrapper import SPARQLWrapper, JSON
import wikipedia
import urllib


class get_comment_boxes():

    def __init__(self, perceived):
        self.perceived = perceived

    def dbpedia_wikipedia_comment_boxes(self):
        list_comment_perceived = []
        self.perceived = self.perceived.capitalize()
        sparql_perceived = SPARQLWrapper("http://dbpedia.org/sparql")
        sparql_perceived.setQuery(""" PREFIX dbpedia-owl: <http://dbpedia.org/ontology/>
                            SELECT DISTINCT ?comment WHERE{
                            ?entry rdfs:label \"""" + self.perceived + """\"@en. 
                            ?entry dbpedia-owl:abstract ?comment
                            FILTER(lang (?comment) = 'en')}
                        """)
        sparql_perceived.setReturnFormat(JSON)
        results_perceived = sparql_perceived.query().convert()
        comment_perceived = results_perceived['results']['bindings']
        if results_perceived['results']['bindings'] != []:
            list_comment_perceived.append(comment_perceived[0]['comment']['value'])
        else:
            entity_comment_perceived = wikipedia.search(self.perceived)
            if entity_comment_perceived != []:
                try:
                    comment_perceived = wikipedia.page(entity_comment_perceived)
                    list_comment_perceived.append(comment_perceived.summary)
                except Exception as e:
                    comment_perceived_exception = e.options[0]
                    comment_perceived1 = wikipedia.page(comment_perceived_exception)
                    list_comment_perceived.append(comment_perceived1)
        if 'WikipediaPage'.lower() in str(list_comment_perceived[0]).lower():
            helper_wikipedia = str(list_comment_perceived[0]).replace('<WikipediaPage ', '').replace('>', '')
            print(helper_wikipedia)
            wikipedia_comment = wikipedia.page(helper_wikipedia)
            list_comment_perceived = []
            list_comment_perceived.append(wikipedia_comment.summary)

        bad_chars = [';', ':', '!', "*", "@", "\n", "%", "?", ".", "-", "_", "&", "'s", ",", ";", "(", ")", "[", "]",
                    "{", "}", "~", "\r", "+", "$", "1", "0", "2", "3", "4", "5", "6", "7", "8", "9", "\""]

        if list_comment_perceived != []:
            for char in bad_chars:
                list_comment_perceived[0] = list_comment_perceived[0].replace(str(char), "")
        return list_comment_perceived