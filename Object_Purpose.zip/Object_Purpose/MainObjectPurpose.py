from Data_Preparation import *
from DBpedia_CB import *
from Οntology import *
from Sorting  import *
import requests

f = open("MiniTest.txt", "r")
f1 = f.readlines()
startinglist = []
for x in f1:
    x = x.rstrip('\n')
    startinglist.append(x)

f.close()

def Remove(duplicate):
    final = []
    for num in duplicate:
        if num not in final:
            final.append(num)
    return final


class ConceptNet:

    def __init__(self, term, uri):
        self.term = term
        self.uri = uri

    def myfunc(self):
        return 'http://api.conceptnet.io/c/en/' + self.term + '?offset=0&limit=1000'

    def myfunc1(self):
        return 'http://conceptnet.io/c/en/' + self.term + '?rel=' + self.uri + '&limit=10'

for i in startinglist:
    objects = i.split(", ")
    if len(objects) == 1:
        list1 = [i]
        if wn.synsets(i) != []:
            print(list1)
            i = i.lower()

            for j in range(len(list1)):
                list1[j] = list1[j].lower()
            lst = []
            lst2 = []
            for j in range(len(list1)):
                object = ConceptNet(list1[j], [])
                property_values = object.myfunc()
                respone = requests.get(property_values)
                obj = respone.json()
                lst0 = []
                for relation in obj['edges']:
                    if ('wordnet' in relation['sources'][0]['@id']) or ('verbosity' in relation['sources'][0]['@id']):
                        lst0.append(1)
                    else:
                        lst0.append(0)

                lst = [relation['rel']['@id'] for relation in obj['edges']]
                lst2 = [relation['@id'] for relation in obj['edges']]
                lst3 = [relation['weight'] for relation in obj['edges']]


                preparation = Find_Similarity(lst2, lst, list1, lst3, "Main")
                cleaned_entities_first = preparation.cleaning_entities()
                cleaned_entities_second, weights_of_entities = preparation.cleaning_entities_second(cleaned_entities_first[1], cleaned_entities_first[0])
                cleaned_weights_final = preparation.grounding(cleaned_entities_second, weights_of_entities)

                ontology = Ontology_Info(i, [])
                actions, activities = ontology.SPARQL_Generator_ONEObject()

                comment_box = get_comment_boxes(list1[j])
                clean_comment_box = comment_box.dbpedia_wikipedia_comment_boxes()
                len_comment = len(clean_comment_box[0].split(" "))

                sorting = Sorting_Purposes(list1[0], cleaned_weights_final, clean_comment_box[0], len_comment, actions, activities)
                sorting.find_important_purposes()
        else:
            print("Give me another word, I could not find something for this one!")
            break
    elif len(objects) > 1:
        print(objects)
        weights = {}
        comment_hash = {}
        len_comment_box = {}
        actions_hash = {}
        activities_hash ={}
        for i in objects:
            list1 = [i]
            if wn.synsets(i) != []:
                print("Looking for information about " + str(list1))
                i = i.lower()

                for j in range(len(list1)):
                    list1[j] = list1[j].lower()
                lst = []
                lst2 = []
                for j in range(len(list1)):
                    object = ConceptNet(list1[j], [])
                    property_values = object.myfunc()
                    respone = requests.get(property_values)
                    obj = respone.json()
                    lst0 = []
                    for relation in obj['edges']:
                        if ('wordnet' in relation['sources'][0]['@id']) or ('verbosity' in relation['sources'][0]['@id']):
                            lst0.append(1)
                        else:
                            lst0.append(0)

                    lst = [relation['rel']['@id'] for relation in obj['edges']]
                    lst2 = [relation['@id'] for relation in obj['edges']]
                    lst3 = [relation['weight'] for relation in obj['edges']]

                    preparation = Find_Similarity(lst2, lst, list1, lst3)
                    cleaned_entities_first = preparation.cleaning_entities()
                    cleaned_entities_second, weights_of_entities = preparation.cleaning_entities_second(
                        cleaned_entities_first[1], cleaned_entities_first[0])
                    cleaned_weights_final = preparation.grounding(cleaned_entities_second, weights_of_entities)

                    ontology = Ontology_Info(i, [])
                    actions, activities = ontology.SPARQL_Generator_ONEObject()

                    comment_box = get_comment_boxes(list1[j])
                    clean_comment_box = comment_box.dbpedia_wikipedia_comment_boxes()
                    len_comment = len(clean_comment_box[0].split(" "))
                    weights[list1[j]] = cleaned_weights_final
                    comment_hash[list1[j]] = clean_comment_box
                    len_comment_box[list1[j]] = len_comment
                    actions_hash[list1[j]] = actions
                    activities_hash[list1[j]] = activities
        sorting = Sorting_Purposes(objects, weights, comment_hash, len_comment_box, actions_hash, activities_hash)
        sorting.find_important_puporses_multiobject()

    else:
        print("No data was given!")
        exit()
