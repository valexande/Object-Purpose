from subprocess import STDOUT, PIPE, Popen, run
from nltk.corpus import wordnet as wn
import requests
from Data_Preparation import *

class Ontology_Info():

    def __init__(self, word, list_affordances):
        self.word = word
        self.list_affordances = list_affordances

    def myfunc(self, action):
        return 'http://api.conceptnet.io/c/en/' + action + '?offset=0&limit=1000'

    def myfunc1(self):
        return 'http://conceptnet.io/c/en/' + self.term + '?rel=' + self.uri + '&limit=10'

    def Remove(self, list_results):
        final_list = []
        for num in list_results:
            if num not in final_list:
                final_list.append(num)
        return final_list

    def SPARQL_Generator_ONEObject(self):
        counter = ['1', '2', '3', '4', '5']
        list_results_actions = []
        for c in counter:
            entity = self.word + c
            try:
                f = open("SPARQL_Query.txt", "w")
                SPARQL = """
                             PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                             PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                             PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                             SELECT DISTINCT ?action WHERE {
			                 ?step rdf:type :Step;
                             :object :""" + str(entity) + """; :step_type ?action}"""
                f.write(SPARQL)
                f.close()
                sparql_results = self.ontology_parsing()
                sparql_results = self.Remove(sparql_results)
                list_results_actions = list_results_actions + sparql_results
            except Exception:
                continue

        list_results_activities = []
        for c in counter:
            entity = self.word + c
            try:
                f = open("SPARQL_Query.txt", "w")
                SPARQL = """
                            PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                            PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                            PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                            SELECT DISTINCT ?y WHERE { ?x rdfs:subClassOf :Activities . ?y rdfs:subClassOf ?x.
			                ?z rdf:type ?y;  :listOfSteps ?list. ?list rdf:rest*/rdf:first ?step .
			                ?step :object :""" + str(entity) + """ . ?step :step_type ?action}
                        """
                f.write(SPARQL)
                f.close()
                sparql_results = self.ontology_parsing()
                sparql_results = self.Remove(sparql_results)
                list_results_activities = list_results_activities + sparql_results
            except Exception:
                continue


        list_results_activities = self.Remove(list_results_activities) #List with activities related to object
        list_results_actions = self.Remove(list_results_actions)#List with action related to object
        return list_results_actions, list_results_activities

    def equivalent_objects(self):
        print(self.list_affordances)
        print("On which affordance do you want to search for?")
        choice = input()
        action = self.list_affordances[int(choice) - 1]
        print("You choose the affordance " + str(action))
        property_values = self.myfunc(action)
        respone = requests.get(property_values)
        obj = respone.json()
        lst0 = []
        for relation in obj['edges']:
            if ('wordnet' in relation['sources'][0]['@id']) or ('verbosity' in relation['sources'][0]['@id']):
                lst0.append(1)
            else:
                lst0.append(0)

        lst = [relation['rel']['@id'] for relation in obj['edges']]
        lst2 = [relation['@id'] for relation in obj['edges']]
        lst3 = [relation['weight'] for relation in obj['edges']]

        preparation = Find_Similarity(lst2, lst, action, lst3, "Other")
        cleaned_entities_first = preparation.cleaning_entities()
        cleaned_entities_second, weights_of_entities = preparation.cleaning_entities_second(cleaned_entities_first[1], cleaned_entities_first[0])
        cleaned_hash_new = {}
        for property in cleaned_entities_second:
            list_for_property = []
            for entity in cleaned_entities_second[property]:
                entity = entity.replace(str(action), "")
                if entity != str(self.word):
                    if wn.synsets(entity) !=[]:
                        list_for_property.append(entity)
            cleaned_hash_new[property] = list_for_property

        word_net = wn.synsets(self.word)[0]
        depth = min([len(path) for path in word_net.hypernym_paths()])
        if depth > 7:
            while depth > 7:
                filter = word_net.hypernyms()
                word_net = filter[0]
                depth = depth - 1

        list_common = []
        local_affordances = self.action_object(action)
        if str(local_affordances) != 'None':
            cleaned_hash_new['HomeOntology'] = local_affordances
        else:
            cleaned_hash_new['HomeOntology'] = []
        for property in cleaned_hash_new:
            for entity in cleaned_hash_new[property]:
                word_net = wn.synsets(entity)[0]
                depth = min([len(path) for path in word_net.hypernym_paths()])
                if depth > 7:
                    while depth > 7:
                        filter_value = word_net.hypernyms()
                        if filter_value != []:
                            word_net = filter_value[0]
                            depth = depth - 1
                        else:
                            break
                    if filter_value != []:
                        if str(filter[0]) == str(filter_value[0]):
                            list_common.append(entity)

        if list_common != []:
            print("Similar objects that you can use them to " + str(action) + " are:")
            list_common = self.Remove(list_common)
            if self.word in list_common:
                list_common.remove(str(self.word))
            print(list_common)
        else:
            print("Sorry I could not find similar objects based on the action " + str(action) + "!")

    def action_object(self, action):
        try:
            f = open("SPARQL_Query.txt", "w")
            SPARQL = """
                                     PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                                     PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                                     PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                                     SELECT DISTINCT ?object WHERE {
        			                 ?instance rdfs:subClassOf :Activities . ?int rdfs:subClassOf ?instance .
        			                 ?in rdf:type ?int . ?in :listOfSteps ?list. ?list rdf:rest*/rdf:first ?step.
        			                 ?step :object ?object ; :step_type :""" + str(action) + """ . }"""
            f.write(SPARQL)
            f.close()
            sparql_results = self.ontology_parsing()
            sparql_results = self.Remove(sparql_results)
            for entity in range(len(sparql_results)):
                sparql_results[entity] = sparql_results[entity].replace("1", "").replace("2", "").replace("3", "").replace("4", "").replace("5", "").replace("_", "")
                sparql_results_final = []
                for word in sparql_results:
                    if wn.synsets(word) != []:
                        sparql_results_final.append(word)
            return sparql_results_final
        except Exception:
            pass

    def ontology_parsing(self):##Gets the query and return rsults form local ontology
        f = open('SPARQL_Query.txt', 'r')
        query_line = ""
        for line in f:
            query_line = query_line + line
        query = query_line.replace('\n', ' ')
        query = ' '.join(query.split())
        f.close()
        sparql_results = self.compile_java('NewTry.jar', query)
        return sparql_results


    def compile_java(self, java_file, query):##Mkes the display of the results from our ontology
        p = run(['java', '-jar', java_file], stdout=PIPE, input=query, encoding='utf-8')
        results = list(p.stdout)
        arrays = [[results[0]]]
        for i in range(1, len(results)):
            if results[i] != '\n':
                arrays[len(arrays) - 1].append([results[i]])
            else:  # otherwise
                arrays.append([])  # Make a new sub-array

        list_with_answers = []
        for i in range(len(arrays)):
            results_sparql = ""
            for j in arrays[i]:
                results_sparql = results_sparql + j[0]
            list_with_answers.append(results_sparql)
        counter = 0
        list_results = []
        try:
            for answer in list_with_answers:
                if counter > 2:
                    answer = answer.split(") (")
                    result = ""
                    for entity in answer:
                        entity = entity.split("=")
                        if entity != ['']:
                            if '#' in str(entity[1]):
                                res = entity[1].split('#')[1].replace('>', '').replace(' )', '') + " "
                            else:
                                res = entity[1] + " "
                        result = result + res
                    list_results.append(result.replace(" ", ""))
                counter += 1
            return list_results
        except Exception:
            pass




"""    Code for the local affordances it was not very helpfull
        counter = ['1', '2', '3', '4', '5']
        try:
            list_results = []
            for c in counter:
                f = open("SPARQL_Query.txt", "w")
                SPARQL =   PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                              PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                              PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                              SELECT DISTINCT ?object WHERE { ?x rdfs:subClassOf :Activities .  ?y rdfs:subClassOf ?x . 
                              ?z rdf:type ?y . ?z :listOfSteps ?list .  ?list rdf:rest*/rdf:first ?step.     
                              ?step :object : + str(self.word) + str(c) + ; :step_type : + str(action) + .
                              ?y1 rdfs:subClassOf ?x .  ?z1 rdf:type ?y1 . ?z1 :listOfSteps ?list1 . ?list1 rdf:rest*/rdf:first ?step1.
                              ?step1 :object ?object ; :step_type : + str(action) + .}
                f.write(SPARQL)
                f.close()
                sparql_results = self.ontology_parsing()
                sparql_results = self.Remove(sparql_results)
                list_results = list_results + sparql_results
            hyper = str(wn.synsets(self.word)[0].hypernyms()[0].name())
            for similar in list_results:
                try:
                    hyper1 = str(wn.synsets(similar.replace("_", "").replace("1", "").replace("2", "").replace("3", "").replace("4", "").replace("5", ""))[0].hypernyms()[0].name())
                    if hyper1 == hyper:
                        print(similar)
                except Exception:
                    continue
        except Exception:
            print()
"""