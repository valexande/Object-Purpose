from Οntology import *
from nltk.stem import PorterStemmer
from nltk.corpus import wordnet as wn
class Sorting_Purposes():
    def __init__(self, perceived, hash_purposes, comment, length, actions, activities):
        self.perceived = perceived
        self.hash_purposes = hash_purposes
        self.comment = comment
        self.length = length
        self.actions = actions
        self.activities = activities

    def intersect(self, *d):
        sets = iter(map(set, d))
        result = sets.next()
        for s in sets:
            result = result.intersection(s)
        return result

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def Remove2(self, duplicate):
        final = []
        for num in duplicate:
            if num in final:
                final.append(num)
        return final

    def find_important_purposes(self):
        porter = PorterStemmer()
        remove = ['putin', 'puton', 'putback', 'putobjback', 'greet', 'laugh', 'jump', 'leave', 'pull', 'push', 'climb',\
                  'crawl', 'dance', 'speak', 'standup', 'spit', 'talk', 'wakeup', 'walk', 'lookat', 'turnto', 'find']
        for re in remove:
            if re in self.actions:
                self.actions.remove(str(re))

        hash_property = {}
        for property in self.hash_purposes:
            for entity in self.hash_purposes[property]:
                if hash_property.get(property) == None:
                    hash_property.setdefault(property, []).append(entity[0])
                else:
                    hash_property[property].append(entity[0])

        KEYS = list(hash_property.keys())
        if '/r/UsedFor' in KEYS:
            hash_property['/r/UsedFor'] = self.Remove(hash_property['/r/UsedFor'] + self.actions)

            list_usedfor = []
            for entity in hash_property['/r/UsedFor']:
                list_usedfor.append(porter.stem(entity))
            hash_property['/r/UsedFor'] = self.Remove(list_usedfor)

            list_usedfor = []
            list_usedfor_2 = []
            for entity in hash_property['/r/UsedFor']:
                if entity in self.comment:
                    list_usedfor.append(entity.replace(entity, entity + "_wiki"))
                else:
                    list_usedfor_2.append(entity)
            hash_property['/r/UsedFor'] = list_usedfor_2 + list_usedfor


        hash_helping_properties = {}
        for property in hash_property:
            for entity in hash_property[property]:
                if wn.synsets(entity.replace("_wiki", "")) != []:
                    if hash_helping_properties.get(property) == None:
                        hash_helping_properties.setdefault(property, []).append(entity.replace("_wiki", ""))
                    else:
                        hash_helping_properties[property].append(entity.replace("_wiki", ""))


        for property in hash_helping_properties:
            help_display = ""
            for entity in hash_helping_properties[property]:
                help_display = help_display + " !" + str(entity) + "! "
            print(self.perceived + " ----> " + str(property) + " " + help_display)
        print("\n")

        affordances = Ontology_Info(self.perceived, hash_helping_properties['/r/UsedFor'])            ##IF YOU DO NOT LIKE THE SIMILAR OBJECT ID DELETE THOSE TWO
        affordances.equivalent_objects()

    def find_important_puporses_multiobject(self):
        porter = PorterStemmer()
        remove = ['putin', 'puton', 'putback', 'putobjback', 'greet', 'laugh', 'jump', 'leave', 'pull', 'push', 'climb',\
                  'crawl', 'dance', 'speak', 'standup', 'spit', 'talk', 'wakeup', 'walk', 'lookat', 'turnto', 'find']
        for property in self.actions:
            for re in remove:
                if re in self.actions[property]:
                    self.actions[property].remove(str(re))
        inter_actions = set.intersection(*(set(val) for val in self.actions.values()))  #Intersaction of local Items
        inter_activities = set.intersection(*(set(val) for val in self.activities.values())) # Intersection of activities
        print("Possible Activities: " + str(inter_activities))

        for obj in self.hash_purposes:
            for property in self.hash_purposes[obj]:
                list_properties = []
                for entity in self.hash_purposes[obj][property]:
                    list_properties.append(entity[0])
                self.hash_purposes[obj][property] = list_properties


        hash_helping_properties = {}
        for obj in self.hash_purposes:
            for property in self.hash_purposes[obj]:
                if hash_helping_properties.get(property) == None:
                    hash_helping_properties.setdefault(property, []).append(self.hash_purposes[obj][property])
                else:
                    hash_helping_properties[property].append(self.hash_purposes[obj][property])

        self.hash_purposes = {}
        list_helper = []
        for property in hash_helping_properties:
            for lst in hash_helping_properties[property]:
                list_helper = list_helper + lst
            if property == '/r/UsedFor':
                self.hash_purposes[property] = list(inter_actions) + list_helper
            else:
                self.hash_purposes[property] = self.Remove2(list_helper)


        for property in self.hash_purposes:
            help_display = ""
            for entity in self.hash_purposes[property]:
                help_display = help_display + " !" + str(entity) + "! "
            if  self.hash_purposes[property] != []:
                print("The perceived objects -----> " + str(property.replace('/r/', '')) + " " + help_display)
            else:
                print("No common entity found for property " + str(property.replace('/r/', '')))
