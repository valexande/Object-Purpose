package HouseTest;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import org.apache.jena.iri.impl.Main;

import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.util.FileManager;

public class HouseTestOnto {
	public static void main(String[] args) {
		sparqlTest();
	}
	
	static void sparqlTest() {
		FileManager.get().addLocatorClassLoader(Main.class.getClassLoader());
		Model model = FileManager.get().loadModel("C:/Users/Alex Vasiliadis/eclipse-workspace/Household Test/SoCoLA_Populated.ttl");
		System.out.println("Your Query Please");
		Scanner myQuery = new Scanner(System.in);
		String sc = myQuery.nextLine();
		System.out.println(sc);
	    String queryString = sc;
		Query query = QueryFactory.create(queryString);
	    QueryExecution qexec = QueryExecutionFactory.create(query, model);
	    BufferedWriter writer = null;
	    try
	    {
	       writer = new BufferedWriter( new FileWriter("output.txt"));
	       try {
	    	   ResultSet results = qexec.execSelect();
	    	   System.out.println(results);
	    	   while (results.hasNext()) {
	    		   QuerySolution sol = results.nextSolution();
	    		   String sol1 = sol.toString();
	    		   System.out.println(sol1);
	    	       writer.write(sol1);
	    	       writer.write(System.lineSeparator());
	    	   }
	       } finally {qexec.close();}
	    }
    catch ( IOException e)
    {
    }
    finally
    {
       try
       {
           if ( writer != null)
           writer.close( );
       }
       catch ( IOException e)
       {
       }
    }
    
	}
}
